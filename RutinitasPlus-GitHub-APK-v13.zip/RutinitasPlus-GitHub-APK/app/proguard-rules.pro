# Tidak ada aturan tambahan. Aplikasi memakai WebView lokal.

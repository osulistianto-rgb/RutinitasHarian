RUTINITAS HARIAN — PROYEK ANDROID

Fungsi:
- Aplikasi berjalan tanpa internet.
- Data disimpan secara lokal pada HP melalui localStorage WebView.
- Ikon muncul pada layar utama setelah APK dipasang.
- Nama paket: id.rutinitas.harian
- Versi: 1.0
- Minimal Android: Android 7.0 (API 24)

CARA MEMBUAT APK DENGAN ANDROID STUDIO
1. Instal Android Studio pada laptop/PC.
2. Ekstrak ZIP proyek ini.
3. Buka Android Studio.
4. Pilih Open, lalu pilih folder RutinitasHarian-Android.
5. Tunggu Gradle Sync selesai. Android Studio mungkin mengunduh SDK/komponen yang diperlukan.
6. Pilih menu Build > Build Bundle(s) / APK(s) > Build APK(s).
7. Setelah selesai, klik Locate.
8. APK debug berada di:
   app/build/outputs/apk/debug/app-debug.apk
9. Kirim APK tersebut ke HP dan buka untuk memasangnya.
10. Jika muncul peringatan, izinkan "Instal aplikasi tidak dikenal" untuk aplikasi File Manager/Chrome yang dipakai membuka APK.

CATATAN
- Jangan menghapus data aplikasi apabila catatan ingin dipertahankan.
- Menghapus aplikasi akan menghapus data lokalnya.
- Untuk cadangan data, fitur ekspor/impor dapat ditambahkan pada versi berikutnya.

# Rutinitas Harian Android v0.2

Proyek Android pembungkus WebView untuk aplikasi Rutinitas Harian.

## Build

```bash
./gradlew assembleDebug
```

Hasil APK:

`app/build/outputs/apk/debug/app-debug.apk`

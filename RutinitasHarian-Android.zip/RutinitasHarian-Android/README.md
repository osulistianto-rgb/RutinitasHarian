# Rutinitas Harian Android

Aplikasi Android WebView yang memuat `app/src/main/assets/index.html` secara lokal.
Data rutinitas disimpan di penyimpanan lokal WebView pada perangkat.

Build debug:

```bash
chmod +x gradlew
./gradlew assembleDebug
```

APK keluaran:
`app/build/outputs/apk/debug/app-debug.apk`

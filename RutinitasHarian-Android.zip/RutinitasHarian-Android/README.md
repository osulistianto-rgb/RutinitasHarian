# Rutinitas Harian Android v0.2

Proyek Android WebView tanpa dependensi AndroidX/Kotlin tambahan.

## Build

```bash
chmod +x gradlew
./gradlew assembleDebug
```

Hasil APK:

`app/build/outputs/apk/debug/app-debug.apk`

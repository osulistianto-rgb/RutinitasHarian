# Tidak ada aturan khusus. Aplikasi hanya menampilkan aset HTML lokal dalam WebView.

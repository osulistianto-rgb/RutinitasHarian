# Tidak ada aturan khusus. Aplikasi hanya memuat aset HTML lokal di WebView.

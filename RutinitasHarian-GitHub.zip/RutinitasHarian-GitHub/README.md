# Rutinitas Harian

Aplikasi Rutinitas Harian berbasis HTML yang dapat dijalankan melalui GitHub Pages.

## Cara mengaktifkan GitHub Pages

1. Unggah seluruh isi folder ini ke repository GitHub.
2. Buka **Settings** pada repository.
3. Pilih **Pages**.
4. Pada bagian **Build and deployment**, pilih **Deploy from a branch**.
5. Pilih branch **main** dan folder **/(root)**.
6. Tekan **Save**.

File utama aplikasi adalah `index.html`.

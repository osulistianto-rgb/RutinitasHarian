package com.rutinitas.plus;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.*;
import android.net.Uri;
import android.content.Intent;
import android.content.ActivityNotFoundException;
public class MainActivity extends Activity {
  private WebView webView;
  private ValueCallback<Uri[]> fileCallback;
  private static final int FILE_CHOOSER=1001;
  @Override public void onCreate(Bundle b){
    super.onCreate(b);
    webView=new WebView(this); setContentView(webView);
    WebSettings s=webView.getSettings();
    s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
    s.setAllowFileAccess(true); s.setAllowContentAccess(true);
    webView.setWebViewClient(new WebViewClient());
    webView.setWebChromeClient(new WebChromeClient(){
      @Override public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams p){
        if(fileCallback!=null) fileCallback.onReceiveValue(null);
        fileCallback=cb;
        try{ startActivityForResult(p.createIntent(),FILE_CHOOSER); }
        catch(ActivityNotFoundException e){ fileCallback=null; return false; }
        return true;
      }
    });
    webView.loadUrl("file:///android_asset/index.html");
  }
  @Override protected void onActivityResult(int r,int c,Intent d){
    if(r==FILE_CHOOSER){ Uri[] res=WebChromeClient.FileChooserParams.parseResult(c,d); if(fileCallback!=null) fileCallback.onReceiveValue(res); fileCallback=null; return; }
    super.onActivityResult(r,c,d);
  }
  @Override public void onBackPressed(){ if(webView.canGoBack()) webView.goBack(); else super.onBackPressed(); }
}

# Rutinitas Harian v0.3.4 + Laporan Rehab

## Upload ke GitHub
1. Ekstrak ZIP.
2. Buka repository GitHub.
3. Pilih **Add file → Upload files**.
4. Unggah seluruh isi folder hasil ekstrak.
5. Klik **Commit changes**.

## GitHub Pages
Buka **Settings → Pages** lalu pilih **GitHub Actions**.

## Membuat APK
Buka tab **Actions → Build APK → Run workflow**.
Setelah selesai, unduh artifact **Rutinitas-Plus-APK**.
